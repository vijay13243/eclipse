package collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;
public class DistinctCustomerList {
	
	/**
	 *
	 * @author Er. Dilpreet Kaur
	 */


		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			
	                List <Integer> l1=null;
	                       l1= new ArrayList<>();
	                List <Integer> l2=null;
	                       l2= new ArrayList<>();
	                        List <Integer> l3=null;
	                       l3= new ArrayList<>();
	                try{       
	                int m = sc.nextInt();
	                if(m>0){
	                for(int i =0 ;i <m;i++)
	                {
	                    l1.add(sc.nextInt());
	                }}
	                
	                int n = sc.nextInt();
	                if(n>0)
	                {
	                for(int i =0 ;i <n;i++)
	                {
	                    l2.add(sc.nextInt());
	                }
	                }
	               Integer[]output= DistinctCustomerList.getDistinctCustomers(l1, l2);
	               if(output==null)
	               {
	               	System.out.println(l3);
	               }
	               else{
	               for(int i=0;i<output.length;i++)
	               {
	                   l3.add(output[i]);
	               }
	               System.out.println(l3);
	               }
	        } catch(Exception e)
	                {
	                  System.out.println(l3);
	                }

		}

		public static Integer[] getDistinctCustomers(List<Integer> first, List<Integer> second) {
			Integer[] output = null;
	                try{
			
	                TreeSet <Integer> t1=new TreeSet<Integer>();
	                TreeSet <Integer> t2=new TreeSet<Integer>();
	              
	                
	                t1.addAll(first);
	                t2.addAll(second);
	                first.clear();
	                second.clear();
	                first.addAll(t1);
	                second.addAll(t2);
	                
	                
	                List<Integer> union = new ArrayList<Integer>(first);
	                union.addAll(second);
	                List<Integer> intersection = new ArrayList<Integer>(first);
	                intersection.retainAll(second);
	                union.removeAll(intersection);
	                
	              
	             
	              
	               
	                 
	                Collections.sort(union, new Comparator<Integer>(){
			
					

	                    @Override
	                    public int compare(Integer o1, Integer o2) {
	                        
	                    if(o1>o2)  
	                        return -1;  
	                    else  
	                        return 1;  
	                    }
				});
	                     
	                  
	                    output = new Integer[union.size()];
	                    for(int k=0;k<union.size();k++)
	                    {
	                       
	                        output[k]=union.get(k);
	                        
	                    }
	                }
	                catch(Exception e)
	                {
	                	output = new Integer[0];
	                    return output;
	                }
	              
	                
	                return output;
			//CODE END
		
		}
	}
	 
/*
 * Problem Statement: List Distinct Customer ID Complete the static method named
 * getDistinctCustomers in the class DistinctCustomerList as given below
 * 
 * The method should take two Lists containing customer id's as inputs. Customer
 * id's are integers and List's can have duplicate customer id's The method
 * should return an array of customer IDs, which are present in either first or
 * second List, but not in both. The returned array should contain unique
 * customer id's in descending order. Note: If the input lists are null,
 * consider them as empty lists
 * 
 * Do the following in the main method
 * 
 * Accept inputs from the console The first input is integer(m) denoting the
 * size of the first List, followed by m number of customer id's The next input
 * is integer(n) denoting the size of the second List, followed by n number of
 * customer id's The output array should be displayed as given in example
 * section Note: If m or n is zero, pass an empty List
 * 
 * Example Sample Input: 3 111 112 113 4 113 112 116 115
 * 
 * Expected Output: [116, 115, 111] Sample Input: 4 101 101 102 103 5 102 103
 * 103 104 105
 * 
 * Expected Output: [105, 104, 101]
 */

